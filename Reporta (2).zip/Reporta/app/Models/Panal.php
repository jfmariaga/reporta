<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Panal extends Model
{
    protected $fillable = [
        'area',
    ];
    use HasFactory;
}
