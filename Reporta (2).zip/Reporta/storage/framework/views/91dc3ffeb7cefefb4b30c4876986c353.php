<div>
    <div class="card direct-chat direct-chat-primary">
        <div class="card-header">
            <h3 class="card-title">Chat de Comentarios</h3>
        </div>
        <div class="card-body">
            <div class="direct-chat-messages">
                <!--[if BLOCK]><![endif]--><?php if($comentarios != null): ?>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $comentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!--[if BLOCK]><![endif]--><?php if($item->user_id): ?>
                            <div class="direct-chat-msg right">
                                <div class="direct-chat-infos clearfix">
                                    <span
                                        class="direct-chat-name float-right"><?php echo e($item->user->name ?? 'Anónimo'); ?></span>
                                    <span
                                        class="direct-chat-timestamp float-left"><?php echo e($item->created_at->format('d M Y h:i a')); ?></span>
                                </div>
                                <div class="direct-chat-text">
                                    <?php echo e($item->comentario); ?>

                                </div>
                            </div>
                        <?php else: ?>
                            <div class="direct-chat-msg">
                                <div class="direct-chat-infos clearfix">
                                    <span
                                        class="direct-chat-name float-left"><?php echo e($item->reporte->ReportadoPor ?? 'Anónimo'); ?></span>
                                    <span
                                        class="direct-chat-timestamp float-right"><?php echo e($item->created_at->format('d M Y h:i a')); ?></span>
                                </div>
                                <div class="direct-chat-text">
                                    <?php echo e($item->comentario); ?>

                                </div>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                <?php else: ?>
                    <div class="card-body">
                        <strong>No existen comentarios para este reporte</strong>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
        <div class="card-footer">
            <!--[if BLOCK]><![endif]--><?php if($estado == 3 || $estado == 4 || $estado == 5): ?>
                <form wire:submit.prevent="submit">
                    <div class="input-group">
                        <input disabled type="text" placeholder="Escribe un comentario ..." class="form-control"
                            wire:model="mensaje">
                        <span class="input-group-append">
                            <button disabled type="submit" class="btn btn-primary">Enviar</button>
                        </span>
                    </div>
                </form>
            <?php else: ?>
                <form wire:submit.prevent="submit">
                    <div class="input-group">
                        <input type="text" placeholder="Escribe un comentario ..." class="form-control"
                            wire:model="mensaje">
                        <span class="input-group-append">
                            <button type="submit" class="btn btn-primary">Enviar</button>
                        </span>
                    </div>
                </form>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Reporta\resources\views/livewire/comentario/new-comentario.blade.php ENDPATH**/ ?>