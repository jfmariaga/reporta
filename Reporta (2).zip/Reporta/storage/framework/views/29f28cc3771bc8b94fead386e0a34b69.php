<div>
    <!--[if BLOCK]><![endif]--><?php if($modelId): ?>
        <div class="form-group col-lg-6 col-12">
            <label><b>Área del reporte</b></label>
            <select wire:model.live="area" class="form-control">
                <option value="" selected>Seleccionar...</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $areasUnicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->area); ?>"> <?php echo e($item->area); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </select>
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="input_error"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <br>
        <br>
        <div class="form-group floating-label-form-group col-lg-12 col-12">
            <label class="float-left"><b>Cargo</b></label>
            <select wire:model.defer="responsable" class="form-control">
                <option value="" selected>Seleccionar...</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"> <?php echo e($item->name); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </select>
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['responsable'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="c_error2 error text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <br>
        <div class="float-right">
            <button class="btn btn-sm btn-outline-primary" wire:click="update()">Guadar</button>
            <button class="btn btn-sm btn-outline-danger" wire:click="resetear()" class="close" data-dismiss="modal"
                aria-label="Close">Cancelar</button>
        </div>
    <?php else: ?>
        <div class="spinner-border text-primary" role="status">
            <span class=" text-center"></span>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

</div>
<?php /**PATH C:\xampp\htdocs\Reporta\resources\views/livewire/gestion/gestion-edit.blade.php ENDPATH**/ ?>