<div>
    <div class="form-group floating-label-form-group col-lg-12 col-12">
        <textarea class="form-control" name="respuesta" wire:model.defer="comentario" id="" cols="40"
            rows="4" placeholder="Si no estas conforme con esta solución por favor escribe aquí el motivo"></textarea>
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['comentario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="c_error2 error text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
    </div>
    <div class="row">
        <div wire:loading wire:target="update" class="alert alert-secondary alert-dismissible fade show"
            role="alert">
            <strong>Procesando...</strong>
        </div>
    </div>
    <br>
    <div class="float-right">
        <button class="btn btn-sm btn-outline-primary" wire:loading.attr="disabled" wire:click="update()">Guadar</button>
        <button class="btn btn-sm btn-outline-danger" wire:click="resetear()" class="close" data-dismiss="modal"
            aria-label="Close">Cancelar</button>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Reporta\resources\views/livewire/consultar/rechazar-consulta.blade.php ENDPATH**/ ?>