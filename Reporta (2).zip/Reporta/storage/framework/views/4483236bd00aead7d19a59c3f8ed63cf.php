<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Areas de impacto</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-lg-12 ">
                <div class="float-right">
                    <a href="#" class="btn btn-sm btn-outline-success" data-toggle="modal"
                        data-target="#newImpacto"><i class="fa fa-plus"></i></a>
                </div>
            </div>
            <br>
            <br>
            <div class="col-lg-12">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('impacto.index');

$__html = app('livewire')->mount($__name, $__params, 'lw-3051809981-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>
<?php echo $__env->yieldPushContent('modals'); ?>

<?php $__env->startSection('js'); ?>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>


<script>
    Livewire.on('ok_impacto', i => {
        try {
            $('#newImpacto').modal('hide');
            Swal.fire({
                position: 'top-end',
                icon: 'success',
                title: 'Nueva Zona  de Impacto registrada!',
                showConfirmButton: false,
                timer: 1500
            })
        } catch (error) {
            console.log('Error alert', error);
        }
    })
</script>
<script>
    Livewire.on('editImpacto', i => {
        try {
            $('#editImpacto').modal('hide');

            Swal.fire({
                position: 'top-end',
                icon: 'success',
                title: 'Area de impacto editada',
                showConfirmButton: false,
                timer: 1500
            })
        } catch (error) {
            console.log('Error alert', error);
        }
        console.log("llega hasta aqui?");
    })
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Reporta\resources\views/impacto/index.blade.php ENDPATH**/ ?>