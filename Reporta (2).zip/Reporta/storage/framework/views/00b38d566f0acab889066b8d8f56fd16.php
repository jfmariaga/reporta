<div class="modal fade" id="verReportes" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true"
    data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('reporte.ver-reporte');

$__html = app('livewire')->mount($__name, $__params, 'lw-497233552-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Reporta\resources\views/modal/verReportes.blade.php ENDPATH**/ ?>