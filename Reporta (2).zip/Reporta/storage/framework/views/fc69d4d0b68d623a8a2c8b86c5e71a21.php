<div class="modal fade" id="rechazarReportes" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true"
    data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog modal-md" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Rechazar reporte</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('reporte.rechazar-reporte');

$__html = app('livewire')->mount($__name, $__params, 'lw-1965855368-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Reporta\resources\views/modal/rechazarReporte.blade.php ENDPATH**/ ?>