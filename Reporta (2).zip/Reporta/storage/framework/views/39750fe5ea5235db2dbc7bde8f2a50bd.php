<div>
    <div class="mb-2 col-lg-4" style="margin-left: -8px">
        <input wire:model.live="search" class="form-control" placeholder="Buscar...">
    </div>

    <!--[if BLOCK]><![endif]--><?php if($areas->count()): ?>
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th colspan="2">Accion</th>
                </tr>
            </thead>
            <tbody>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->area); ?></td>
                        <!--[if BLOCK]><![endif]--><?php if($item->user_id): ?>
                            <td><?php echo e($item->user->name); ?></td>
                        <?php else: ?>
                            <td>vacio</td>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <td class="text-center">
                            <a href="#" class="btn btn-sm btn-secondary"
                                wire:click="selecItem(<?php echo e($item->id); ?>,'editar')" data-toggle="modal"
                                data-target="#editGestion"><i class="far fa-edit"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
        <div class="card-footer">
            <?php echo e($areas->links()); ?>

        </div>
    <?php else: ?>
        <div class="card-body">
            <strong>No existen datos para mostrar</strong>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <?php $__env->startPush('modals'); ?>
        <?php echo $__env->make('modal.newGestion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('modal.editGestion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopPush(); ?>
</div>

<?php /**PATH C:\xampp\htdocs\Reporta\resources\views/livewire/gestion/index.blade.php ENDPATH**/ ?>