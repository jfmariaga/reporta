<button type="<?php echo e($type); ?>" <?php echo e($attributes->merge(['class' => "btn btn-{$theme}"])); ?>>
    <!--[if BLOCK]><![endif]--><?php if(isset($icon)): ?> <i class="<?php echo e($icon); ?>"></i> <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <!--[if BLOCK]><![endif]--><?php if(isset($label)): ?> <?php echo e($label); ?> <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</button>
<?php /**PATH C:\xampp\htdocs\Reporta\vendor\jeroennoten\laravel-adminlte\src/../resources/views/components/form/button.blade.php ENDPATH**/ ?>