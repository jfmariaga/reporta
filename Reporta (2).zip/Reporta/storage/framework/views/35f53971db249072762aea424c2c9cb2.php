<div>
    
</div>
<?php /**PATH C:\xampp\htdocs\Reporta\resources\views/livewire/consultar/edit-consulta.blade.php ENDPATH**/ ?>