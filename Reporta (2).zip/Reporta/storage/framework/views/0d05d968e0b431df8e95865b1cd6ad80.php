<div>
    <table class="table table-striped table-hover table-bordered dataex-html5-export">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Correo</th>
                <th>Rol</th>
                <th colspan="2">Acción</th>
            </tr>
        </thead>
        <tbody>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($usuario->name); ?></td>
                    <td><?php echo e($usuario->email); ?></td>
                    <td><?php echo e($usuario->roles[0]->name); ?></td>
                    <td class="text-center">
                        <a href="#" class="btn btn-sm btn-warning" wire:click="selecItem(<?php echo e($usuario->id); ?>,'update')"
                            data-toggle="modal" data-target="#editUsuario"><i class="far fa-edit"></i></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </tbody>
    </table>

    <?php $__env->startPush('modals'); ?>
        <?php echo $__env->make('modal.nuevo-usuario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('modal.editar-usuario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopPush(); ?>
</div>

<?php /**PATH C:\xampp\htdocs\Reporta\resources\views/livewire/usuario/usuario.blade.php ENDPATH**/ ?>