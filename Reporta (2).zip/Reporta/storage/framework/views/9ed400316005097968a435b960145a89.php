<div>
    <div class="form-group floating-label-form-group col-lg-12 col-12">
        <label class="float-left"><b>Motivo del rechazo</b></label>
        <textarea class="form-control" name="respuesta" wire:model.defer="respuesta" id="" cols="40"
            rows="4"></textarea>
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['respuesta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="c_error2 error text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
    </div>
    <div class="row mt-3">
        <div wire:loading wire:target="update" class="alert alert-secondary col-12">
            <strong>Procesando...</strong> Por favor espere mientras se termina de procesar esta solicitud.
        </div>
    </div>
    <br>
    <div class="float-right">
        <button class="btn btn-sm btn-outline-primary" wire:loading.attr="disabled" wire:click="update()">Guadar</button>
        <button class="btn btn-sm btn-outline-danger" wire:loading.attr="disabled"  wire:click="resetear()" class="close" data-dismiss="modal"
            aria-label="Close">Cancelar</button>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Reporta\resources\views/livewire/reporte/rechazar-reporte.blade.php ENDPATH**/ ?>