<div>
    <style>
        .form-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .card-body {
            padding: 20px;
        }

        .modal-footer {
            display: flex;
            justify-content: space-between;
        }

        .input_error {
            font-size: 0.9em;
            color: #dc3545;
        }
    </style>
    <div class="container-fluid">
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="form-group col-lg-3 col-12">
                        <label><b>Número de cédula</b></label>
                        <input autocomplete="none" type="number" wire:model.live="search" class="form-control"
                            placeholder="Escribe aquí su cédula">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['search'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="input_error"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <!--[if BLOCK]><![endif]--><?php if(count($empleado) > 0): ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $empleado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group col-lg-3 col-12">
                                <label><b>Nombre de quien reporta</b></label>
                                <input type="text" wire:model.live="nombre"
                                    class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="<?php echo e($item->nombre); ?>" disabled />
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="input_error"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <div class="form-group col-lg-3 col-12">
                                <label><b>A donde quieres que te notifiquemos</b></label>
                                <select wire:model.live="reporEmail" class="form-control" disabled>
                                    <option value="<?php echo e($item->email); ?>"> <?php echo e($item->email); ?> </option>
                                </select>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['reporEmail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="input_error"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <?php else: ?>
                        <div class="form-group col-lg-3 col-12">
                            <label><b>Nombre de quien reporta</b></label>
                            <input type="text" wire:model="nombre"
                                class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Nombre">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="input_error"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="form-group col-lg-3 col-12">
                            <label><b>A donde quieres que te notifiquemos</b></label>
                            <select wire:model.live="reporEmail" class="form-control">
                                <option value="" selected>Seleccionar...</option>
                                <option value="supervisor.almacen@panalsas.com">Wilber Ochoa</option>
                                <option value="supervisor.ambiental@panalsas.com">Robinson Cardona Castrillon</option>
                                <option value="supervisor2.produccion@panalsas.com">Carlos Echeverri</option>
                                <option value="supervisor3.produccion@panalsas.com">Edgar Santiago Lopez Carmona</option>
                                <option value="supervisor4.produccion@panalsas.com">Jesus Ernesto Hoyos</option>
                                <option value="supervisor5.produccion@panalsas.com">Juan Esteban Alzate</option>
                                <option value="supervisor6.produccion@panalsas.com">Carlos Andres Ocampo</option>
                                <option value="supervisor7.produccion@panalsas.com">Jhony Cuervo</option>
                                <option value="supervisor8.produccion@panalsas.com">Alejandro Perez Muñoz</option>
                            </select>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['reporEmail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="input_error"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <div class="form-group col-lg-3 col-12">
                        <label><b>Área a la que perteneces</b></label>
                        <select wire:model.live="panal" class="form-control">
                            <option value="" selected>Seleccionar...</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $panals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->area); ?>"> <?php echo e($item->area); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="input_error"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <!--[if BLOCK]><![endif]--><?php if($cargos): ?>
                        <div class="form-group col-lg-6 col-12">
                            <label><b>Cargo</b></label>
                            <select wire:model.defer="cargo" class="form-control">
                                <option value="" selected>Seleccionar...</option>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $cargos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"> <?php echo e($item->cargo); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </select>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['cargo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="input_error"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <div class="form-group col-lg-6 col-12">
                        <label><b>Área del reporte</b></label>
                        <select wire:model.live="area" class="form-control">
                            <option value="" selected>Seleccionar...</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $areasUnicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->area); ?>"> <?php echo e($item->area); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="input_error"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <!--[if BLOCK]><![endif]--><?php if($zonas): ?>
                        <div class="form-group col-lg-6 col-12">
                            <label><b>Zona especifica de la novedad</b></label>
                            <select wire:model.defer="zona" class="form-control">
                                <option value="" selected>Seleccionar...</option>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $zonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->localicacion); ?>"> <?php echo e($item->localicacion); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </select>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['zona'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="input_error"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <div class="form-group col-lg-6 col-12">
                        <label><b>Selecciona uno o varios sistemas de gestión de impacto</b></label>
                        <select wire:model.defer="impacto" class="form-control" multiple>
                            <option value="" selected>Seleccionar...</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $impactos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"> <?php echo e($item->impacto); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['impacto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="input_error"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <div class="form-group col-lg-6 col-12">
                        <label><b>Descripción del reporte</b></label>
                        <textarea class="form-control" name="descripcion" wire:model="descripcion" cols="30" rows="5"
                            placeholder="Que(Hallazgo), Como(Estado), Donde(Ubicación), Propuesta de mejora"></textarea>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="input_error"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <div class="form-group col-lg-6 col-12">
                        <label><b>Orden de trabajo (solo si la conoces)</b></label>
                        <input type="text" class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            placeholder="# de orden" wire:model="orden">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['orden'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="input_error"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <div class="form-group col-lg-6 col-12">
                        <label><b>Asigna una prioridad al reporte</b></label>
                        <select wire:model.defer="prioridad" class="form-control">
                            <option value="" selected>Seleccionar...</option>
                            <option value="ALTA">ALTA</option>
                            <option value="MEDIA">MEDIA</option>
                            <option value="BAJA">BAJA</option>
                        </select>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['prioridad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="input_error"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <div class="form-group col-6 col-6">
                        <label><b>Agrega un registro fotográfico</b></label>
                        
                        <?php if (isset($component)) { $__componentOriginalc49abe9ea9cb5496814d5780e6ddffe2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc49abe9ea9cb5496814d5780e6ddffe2 = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\InputFile::resolve(['id' => ''.e($identificar).'','name' => 'ifPholder','igroupSize' => 'sm','placeholder' => 'Seleccionar un archivo...'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-input-file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\InputFile::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'img']); ?>
                             <?php $__env->slot('prependSlot', null, []); ?> 
                                <div class="input-group-text bg-lightblue">
                                    <i class="fas fa-upload"></i>
                                </div>
                             <?php $__env->endSlot(); ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc49abe9ea9cb5496814d5780e6ddffe2)): ?>
<?php $attributes = $__attributesOriginalc49abe9ea9cb5496814d5780e6ddffe2; ?>
<?php unset($__attributesOriginalc49abe9ea9cb5496814d5780e6ddffe2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc49abe9ea9cb5496814d5780e6ddffe2)): ?>
<?php $component = $__componentOriginalc49abe9ea9cb5496814d5780e6ddffe2; ?>
<?php unset($__componentOriginalc49abe9ea9cb5496814d5780e6ddffe2); ?>
<?php endif; ?>
                        <div class="row mt-3">
                            <div class="col-12">
                                <!--[if BLOCK]><![endif]--><?php if($img): ?>
                                    <img src="<?php echo e($img->temporaryUrl()); ?>" alt="" class="img-fluid">
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="input_error"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        <div class="row mt-2">
                            <div wire:loading wire:target="img" class="alert alert-secondary col-12">
                                <strong>Cargando imagen</strong> Por favor espere mientras se termina de cargar la
                                imagen.
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-3">
                    <div wire:loading wire:target="guardar" class="alert alert-secondary col-12">
                        <strong>Procesando tu reporte</strong> Por favor espere mientras se termina de procesar el
                        reporte.
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="reset" class="btn btn-outline-secondary btn-sm"
                    wire:click="resetear()">Cancelar</button>
                <button type="submit" class="btn btn-outline-info btn-sm" wire:click="guardar()"
                    wire:loading.attr="disabled" wire:target="img">Guardar</button>
            </div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</div>
<?php /**PATH C:\xampp\htdocs\Reporta\resources\views/livewire/reporte/create-reporte.blade.php ENDPATH**/ ?>