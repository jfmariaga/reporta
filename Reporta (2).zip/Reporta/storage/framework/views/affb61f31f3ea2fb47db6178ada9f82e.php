<div>
    <style>
        #comentarioModal {
            z-index: 1051;
            /* Slightly higher z-index to be on top of the first modal */
        }

        .timeline-horizontal {
            display: flex;
            overflow-x: auto;
            padding: 20px;
            white-space: nowrap;
        }

        .timeline-item {
            display: inline-block;
            background: #f4f4f4;
            border-radius: 10px;
            margin: 5px 20px;
            padding: 10px 20px;
            box-shadow: 0 3px 6px rgba(0, 0, 0, 0.1);
            position: relative;
        }

        .timeline-icon {
            width: 30px;
            height: 30px;
            background-color: #777;
            border-radius: 50%;
            position: absolute;
            left: -15px;
            /* Adjust this value if needed */
            top: 10px;
        }

        .timeline-content {
            padding-left: 40px;
            /* Adjust based on the size of the timeline-icon */
        }

        .timeline-content h2 {
            font-size: 16px;
            font-weight: bold;
            color: #555;
        }

        .timeline-content p {
            font-size: 14px;
            color: #666;
        }
    </style>
    <!--[if BLOCK]><![endif]--><?php if($modelId): ?>
        <div class="modal-header">
            <h5 class="modal-title">Gestionar Reporte con consecutivo <b><?php echo e($consecutivo); ?></b></h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <!--[if BLOCK]><![endif]--><?php if($estado == 7): ?>
                <div class="card">
                    <div class="row">
                        <div class="form-group floating-label-form-group col-lg-12 col-6">
                            <label class="float-left"><b>Comentario de no aceptación</b></label>
                            <textarea class="form-control" name="respuesta" wire:model.defer="comentario" id="" cols="40"
                                rows="4" disabled></textarea>
                        </div>
                    </div>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <!--[if BLOCK]><![endif]--><?php if($estado == 1 || $estado == 2 || $estado == 7): ?>
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <h5 class="text-muted font-weight-bold pt-4 px-3 border-bottom-0 my-3">Seguimiento</h5>
                        </div>
                        <div class="row">
                            <!--[if BLOCK]><![endif]--><?php if(auth()->user()): ?>
                                <div class="col-sm-4 col-md-4 col-lg-4">
                                    <li class="list-group-item">
                                        Gestionar
                                        <div class="float-right">
                                            <label class="switch">
                                                <input type="checkbox" wire:model.live="check">
                                                <span class="slider round"></span>
                                            </label>
                                        </div>
                                    </li>
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <div class="col-sm-4 col-md-4 col-lg-4">
                                <a href="#" wire:click="pasarId(<?php echo e($modelId); ?>)" class="btn btn-lg btn-dark"
                                    data-toggle="modal" data-target="#comentarioModal">Comentarios</a>
                                <a href="#" class="btn btn-lg btn-dark" data-toggle="modal"
                                    data-target="#timeLineModal">TimeLine</a>
                                <div class="modal fade" id="timeLineModal" tabindex="-1" role="dialog"
                                    aria-labelledby="comentarioModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-lg" role="document">
                                        <div class="modal-content">
                                            <div class="modal-body">
                                                <div class="card">
                                                    <div class="card-body">
                                                        <h5 class="text-muted font-weight-bold">Historial del Reporte
                                                        </h5>
                                                        <div class="timeline">
                                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $historial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <div class="timeline-item">
                                                                    <div class="timeline-icon">
                                                                        <!-- Icono o indicador por año/evento, puede ser un círculo o cualquier forma definida en CSS -->
                                                                    </div>
                                                                    <div
                                                                        class="timeline-content <?php echo e($loop->iteration % 2 == 0 ? 'right' : ''); ?>">
                                                                        <h2><?php echo e($evento->fecha); ?></h2>
                                                                        <!-- Fecha del evento -->
                                                                        <p><?php echo e($evento->descripcion); ?></p>
                                                                        <!-- Descripción del evento -->
                                                                    </div>
                                                                </div>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <br>
                        <div class="row <?php echo e($class); ?>">
                            <fieldset class="form-group floating-label-form-group col-lg-6 col-6">
                                <label for=""><b>Selecciona la fecha limite de seguimiento</b></label>
                                <input type="date" class="form-control  <?php $__errorArgs = ['seguimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border_error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    wire:model.defer="seguimiento">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['seguimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="input_error error text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </fieldset>
                            <fieldset class="form-group floating-label-form-group col-lg-6 col-6">
                                <label for=""><b>Asignar una orden de trabajo a este reporte</b></label>
                                <input type="text" oninput="this.value = this.value.replace(/[^a-zA-Z]/,' ')"
                                    onkeyup="javascript:this.value=this.value.toUpperCase();"
                                    class="form-control  <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border_error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="# de orden" wire:model.defer="orden">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['orden'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="input_error error"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </fieldset>
                            <div class="col-md-6 mb-3">
                                <label class="float-left"><b>Agrega un registro fotografico </b></label>
                                <br>
                                <?php if (isset($component)) { $__componentOriginalc49abe9ea9cb5496814d5780e6ddffe2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc49abe9ea9cb5496814d5780e6ddffe2 = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\InputFile::resolve(['id' => ''.e($identificar).'','name' => 'ifPholder','igroupSize' => 'sm','placeholder' => 'Seleccionar un archivo...'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-input-file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\InputFile::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model.defer' => 'img2']); ?>
                                     <?php $__env->slot('prependSlot', null, []); ?> 
                                        <div class="input-group-text bg-lightblue">
                                            <i class="fas fa-upload"></i>
                                        </div>
                                     <?php $__env->endSlot(); ?>
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc49abe9ea9cb5496814d5780e6ddffe2)): ?>
<?php $attributes = $__attributesOriginalc49abe9ea9cb5496814d5780e6ddffe2; ?>
<?php unset($__attributesOriginalc49abe9ea9cb5496814d5780e6ddffe2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc49abe9ea9cb5496814d5780e6ddffe2)): ?>
<?php $component = $__componentOriginalc49abe9ea9cb5496814d5780e6ddffe2; ?>
<?php unset($__componentOriginalc49abe9ea9cb5496814d5780e6ddffe2); ?>
<?php endif; ?>
                                <div class="row">
                                    <div class="col-sm-8 col-md-8 col-lg-8">
                                        <!--[if BLOCK]><![endif]--><?php if($img3): ?>
                                            <br>
                                            <img src="<?php echo e(Storage::url($img3)); ?>" alt=""
                                                style="width: 50%; height: auto;">
                                            <br>
                                            <a target="_blank" href="<?php echo e(Storage::url($img3)); ?>">Ampliar imagen</a>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <!--[if BLOCK]><![endif]--><?php if($img2): ?>
                                            <br>
                                            <img src="<?php echo e($img2->temporaryUrl()); ?>" alt=""
                                                style="width: 50%; height: auto;">
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['img2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="c_error2 error text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                <div class="row">
                                    <div wire:loading wire:target="img2"
                                        class="alert alert-secondary alert-dismissible fade show" role="alert">
                                        <strong>Cargando imagen</strong> Por favor espere mientras se termina de cargar
                                        la
                                        imagen
                                    </div>
                                </div>
                            </div>
                            <div class="form-group floating-label-form-group col-lg-6 col-6">
                                <label class="float-left"><b>Respuesta</b></label>
                                <textarea class="form-control" name="respuesta" wire:model.defer="respuesta" id="" cols="40"
                                    rows="4"></textarea>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['respuesta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="c_error2 error text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>

                            <div class="row">
                                <div wire:loading wire:target="update"
                                    class="alert alert-secondary alert-dismissible fade show" role="alert">
                                    <strong>Procesando...</strong>
                                </div>
                            </div>
                            <div class="row">
                                <div wire:loading wire:target="cerrar"
                                    class="alert alert-secondary alert-dismissible fade show" role="alert">
                                    <strong>Procesando...</strong>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="modal-footer text-center">
                                    <?php if(auth()->user() && auth()->user()->hasRole('JefeArea')): ?>
                                        <!--[if BLOCK]><![endif]--><?php if($estado == 1): ?>
                                            <input type="submit" class="btn btn-outline-info btn-md"
                                                wire:click="update()" value="Aceptar reporte">
                                        <?php else: ?>
                                            <input type="submit" class="btn btn-outline-info btn-md"
                                                wire:click="update()" value="Guardar">
                                            <input type="reset" class="btn btn-outline-secondary btn-md"
                                                wire:click="cerrar()" value="Enviar para seguimiento">
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <!--[if BLOCK]><![endif]--><?php if($estado == 3 || $estado == 4 || $estado == 6): ?>
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <h5 class="text-muted font-weight-bold border-bottom-0 ">Gestion del
                                Reporte</h5>
                        </div>
                        <div class="col-sm-4 col-md-4 col-lg-4">
                            <a href="#" wire:click="pasarId(<?php echo e($modelId); ?>)" class="btn btn-lg btn-dark"
                                data-toggle="modal" data-target="#comentarioModal">Comentarios</a>
                            <a href="#" class="btn btn-lg btn-dark" data-toggle="modal"
                                data-target="#timeLineModal">TimeLine</a>
                            <div class="modal fade" id="timeLineModal" tabindex="-1" role="dialog"
                                aria-labelledby="comentarioModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-lg" role="document">
                                    <div class="modal-content">
                                        <div class="modal-body">
                                            <div class="card">
                                                <div class="card-body">
                                                    <h5 class="text-muted font-weight-bold">Historial del Reporte</h5>
                                                    <div class="timeline-horizontal">
                                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $historial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="timeline-item">
                                                                <div class="timeline-icon"></div>
                                                                <div class="timeline-content">
                                                                    <h2><?php echo e($evento->created_at->format('Y-m-d')); ?></h2>
                                                                    <p><?php echo e($evento->detalle); ?></p>
                                                                </div>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row font-weight-bold pt-4 px-3 border-bottom-0 my-3">
                            <fieldset class="form-group floating-label-form-group col-lg-6 col-6">
                                <label for=""><b>Fecha limite para aceptación</b></label>
                                <input type="date" disabled
                                    class="form-control  <?php $__errorArgs = ['seguimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border_error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    wire:model.defer="seguimiento">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['seguimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="input_error error text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </fieldset>
                            <fieldset class="form-group floating-label-form-group col-lg-6 col-6">
                                <label for=""><b>Orden de trabajo</b></label>
                                <input type="text" oninput="this.value = this.value.replace(/[^a-zA-Z]/,' ')"
                                    onkeyup="javascript:this.value=this.value.toUpperCase();"
                                    class="form-control  <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border_error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="# de orden" wire:model.defer="orden" disabled>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['orden'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="input_error error"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </fieldset>
                            <div class="form-group floating-label-form-group col-lg-6 col-6">
                                <label class="float-left"><b>Respuesta</b></label>
                                <textarea disabled class="form-control" name="respuesta" wire:model.defer="respuesta" id="" cols="40"
                                    rows="4"></textarea>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['respuesta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="c_error2 error text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="float-left"><b>Evidencia </b></label>
                                <br>
                                <div class="row">
                                    <div class="col-sm-6 col-md-6 col-lg-6">
                                        <!--[if BLOCK]><![endif]--><?php if($img3): ?>
                                            <br>
                                            <img src="<?php echo e(Storage::url($img3)); ?>" alt=""
                                                style="width: 50%; height: auto;">
                                            <br>
                                            <a target="_blank" href="<?php echo e(Storage::url($img3)); ?>">Ampliar imagen</a>
                                            <hr>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <h5 class="text-muted font-weight-bold pt-4 px-3 border-bottom-0 my-3">Reporte Inicial</h5>
                    </div>
                    <div class="row">
                        <fieldset class="form-group floating-label-form-group col-lg-6 col-12">
                            <label for=""><b>Nombre de quien reporta</b></label>
                            <input type="text" oninput="this.value = this.value.replace(/[^a-zA-Z]/,' ')"
                                onkeyup="javascript:this.value=this.value.toUpperCase();"
                                class="form-control  <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border_error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Nombre"
                                wire:model.defer="nombre" disabled>
                        </fieldset>
                        <br>
                        <div class="form-group floating-label-form-group col-lg-6 col-12">
                            <label class="float-left"><b>Area del reporte</b></label>
                            <select wire:model.defer="area" class="form-control"
                                <?php if($estado != 1): ?> disabled <?php endif; ?>>
                                <option value="" selected>Seleccionar...</option>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $areasUnicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->area); ?>"> <?php echo e($item->area); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </select>
                        </div>
                        <br>
                        <fieldset class="form-group floating-label-form-group col-lg-6 col-12">
                            <label for=""><b>Zona de la novedad</b></label>
                            <input type="text" class="form-control  <?php $__errorArgs = ['zona'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border_error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Zona" wire:model.defer="zona" disabled>
                        </fieldset>
                        <br>
                        <div class="form-group floating-label-form-group col-lg-6 col-12">
                            <label class="float-left"><b>Cargo de quien reporta</b></label>
                            <select wire:model.defer="cargo" class="form-control" disabled>
                                <option value="" selected>Seleccionar...</option>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $cargos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"> <?php echo e($item->cargo); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </select>
                        </div>
                        <br>
                        <div class="form-group floating-label-form-group col-lg-6 col-12">
                            <label class="float-left"><b>Sistemas de gestion que impacta el reporte</b></label>
                            <select wire:model.defer="impacto" class="form-control" multiple
                                <?php if($estado != 1): ?> disabled <?php endif; ?>>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $impactos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"
                                        <?php echo e(in_array($item->id, $impacto ?? []) ? 'selected' : ''); ?>>
                                        <?php echo e($item->impacto); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </select>
                        </div>
                        <br>
                        <div class="form-group floating-label-form-group col-lg-6 col-12">
                            <label class="float-left"><b>Prioridad al reporte</b></label>
                            <select wire:model.defer="prioridad" class="form-control" disabled>
                                <option value="" selected>Seleccionar...</option>
                                <option value="ALTA">ALTA</option>
                                <option value="MEDIA">MEDIA</option>
                                <option value="BAJA">BAJA</option>
                            </select>
                        </div>
                        <br>
                        <!--[if BLOCK]><![endif]--><?php if(!is_null($orden)): ?>
                            <fieldset class="form-group floating-label-form-group col-lg-12 col-12">
                                <label for=""><b>Orden de trabajo (solo si la conoces)</b></label>
                                <input type="text" oninput="this.value = this.value.replace(/[^a-zA-Z]/,' ')"
                                    onkeyup="javascript:this.value=this.value.toUpperCase();"
                                    class="form-control  <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border_error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="# de orden" wire:model.defer="orden" disabled>
                            </fieldset>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <br>
                        <div class="form-group floating-label-form-group col-lg-6 col-6">
                            <label class="float-left"><b>Descripción del reporte. Que(Hallazgo), Como(Estado),
                                    Donde(Ubicación)</b></label>
                            <textarea class="form-control" name="descripcion" wire:model.defer="descripcion" id="" cols="30"
                                rows="5" disabled></textarea>
                        </div>
                        <br>
                        <!--[if BLOCK]><![endif]--><?php if($estado == 4): ?>
                            <div class="form-group floating-label-form-group col-lg-6 col-6">
                                <label class="float-left"><b>Motivo del rechazo</b></label>
                                <textarea class="form-control mt-4" name="respuesta" wire:model.defer="respuesta" id="" cols="40"
                                    rows="6" disabled></textarea>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <br>
                        <div class="col-md-6">
                            <label class="float-left"><b>Evidencia</b></label>
                            <br>
                            <div class="row">
                                <div class="col-sm-8 col-md-8 col-lg-8">
                                    <!--[if BLOCK]><![endif]--><?php if($img): ?>
                                        <br>
                                        <img src="<?php echo e(Storage::url($img)); ?>" alt=""
                                            style="width: 50%; height: auto;">
                                        <br>
                                        <a target="_blank" href="<?php echo e(Storage::url($img)); ?>">Ampliar imagen</a>
                                        <hr>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--[if BLOCK]><![endif]--><?php if($estado == 1 && auth()->user() && auth()->user()->hasRole('JefeArea')): ?>
                        <div class="modal-footer text-center">
                            <input type="button" class="btn btn-outline-warning btn-md"
                                wire:click="recategorizarReporte()" value="Recategorizar reporte">
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="spinner-border text-primary" role="status">
            <span class=" text-center"></span>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\xampp\htdocs\Reporta\resources\views/livewire/reporte/ver-reporte.blade.php ENDPATH**/ ?>