<div class="modal fade" id="aceptarReportes" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true"
    data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Aceptar Reporte</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Reporta\resources\views/modal/aceptarReporte.blade.php ENDPATH**/ ?>