<div>
    <div class="card">
        <div class="card-body">
            <div class="row">
                <fieldset class="form-group floating-label-form-group col-lg-6 col-12">
                    <label for=""><b>Selecciona el Area</b></label>
                    <select wire:model.live="area" class="form-control">
                        <option value="" selected>Seleccionar...</option>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $areasUnicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->area); ?>"><?php echo e($item->area); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </select>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="input_error error"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </fieldset>
                <br>
                <fieldset class="form-group floating-label-form-group col-lg-6 col-12">
                    <label for=""><b>Localización</b></label>
                    <input type="text" oninput="this.value = this.value.replace(/[^a-zA-Z]/,' ')"
                        onkeyup="javascript:this.value=this.value.toUpperCase();"
                        class="form-control  <?php $__errorArgs = ['localicacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border_error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="localicacion"
                        wire:model="localicacion">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['localicacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="input_error error"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </fieldset>

                <div class="modal-footer">
                    <input type="reset" class="btn btn-outline-secondary btn-sm" wire:click="resetear()"
                        value="Cancelar">
                    <input type="submit" class="btn btn-outline-info btn-sm" wire:click="guardar()" value="Guardar">
                </div>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <div class="mb-2 col-lg-4 " style="margin-left: 13px">
                <input wire:model.live="search" class="form-control" placeholder="Buscar...">
            </div>
            <!--[if BLOCK]><![endif]--><?php if($areas->count()): ?>
                <div class="card-body">
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th style="text-align: center">Area</th>
                                <th style="text-align: center">Localización</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($item->area); ?></td>
                                    <td class="text-center"><?php echo e($item->localicacion); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                </div>
                <div class="card-footer">
                    <?php echo e($areas->links()); ?>

                </div>
            <?php else: ?>
                <div class="card-footer">
                    <h3>No existen datos para mostrar</h3>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>

</div>
<?php /**PATH C:\xampp\htdocs\Reporta\resources\views/livewire/area/area-new.blade.php ENDPATH**/ ?>