<div class="modal fade" id="editUsuario" tabindex="-1" role="dialog" aria-labelledby="modelTitleId"
    aria-hidden="true" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog modal-md" role="document">
        <div class="modal-content">
            @livewire('usuario.editar-usuario')
        </div>
    </div>
</div>
