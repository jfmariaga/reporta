<div class="modal fade" id="verReportes" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true"
    data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            @livewire('reporte.ver-reporte')
        </div>
    </div>
</div>
