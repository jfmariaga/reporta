<div class="modal fade" id="newPanal" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true"
    data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog modal-md" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Nueva area</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                @livewire('panal.panal-new')
            </div>
        </div>
    </div>
</div>
